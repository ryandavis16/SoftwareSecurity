
module moduleThreeStone {
}